<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Notice</title>
</head>
<style>
  body{
    background-color: oldlace;
  }
  h1{
    color: red;
    font-size: 3rem;
  }
</style>
<body>
  <h1>You can't access this site!</h1>
</body>
</html>